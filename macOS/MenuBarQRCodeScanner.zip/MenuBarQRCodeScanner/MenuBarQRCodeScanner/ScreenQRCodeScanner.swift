import AppKit
import CoreGraphics
import CoreImage
import ScreenCaptureKit
import Vision

enum ScreenQRCodeScannerError: LocalizedError {
    case noDisplays
    case screenshotDenied

    var errorDescription: String? {
        switch self {
        case .noDisplays:
            return "No available displays were found."
        case .screenshotDenied:
            return "macOS did not allow this app to capture the screen."
        }
    }
}

final class ScreenQRCodeScanner {
    private let queue = DispatchQueue(label: "MenuBarQRCodeScanner.scan", qos: .userInitiated)

    static func primeScreenCaptureKitPermission(completion: (() -> Void)? = nil) {
        SCShareableContent.getExcludingDesktopWindows(
            true,
            onScreenWindowsOnly: true
        ) { _, _ in
            DispatchQueue.main.async {
                completion?()
            }
        }
    }

    func scanAllDisplays(completion: @escaping (Result<[String], Error>) -> Void) {
        queue.async {
            do {
                let images = try self.captureScreenImages()
                let codes = self.decode(images: images)
                DispatchQueue.main.async {
                    completion(.success(codes))
                }
            } catch {
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }
    }

    private func captureScreenImages() throws -> [CGImage] {
        guard let images = Self.captureWithScreenCaptureKit(), !images.isEmpty else {
            throw ScreenQRCodeScannerError.screenshotDenied
        }
        return images
    }

    private static func captureWithScreenCaptureKit() -> [CGImage]? {
        let semaphore = DispatchSemaphore(value: 0)
        var capturedImages: [CGImage] = []

        SCShareableContent.getExcludingDesktopWindows(
            true,
            onScreenWindowsOnly: true
        ) { content, _ in
            guard let content else {
                semaphore.signal()
                return
            }

            let currentApp = content.applications.first { $0.processID == getpid() }
            let group = DispatchGroup()

            for display in content.displays {
                group.enter()

                let filter: SCContentFilter
                if let currentApp {
                    filter = SCContentFilter(
                        display: display,
                        excludingApplications: [currentApp],
                        exceptingWindows: []
                    )
                } else {
                    filter = SCContentFilter(display: display, excludingWindows: [])
                }

                if #available(macOS 14.2, *) {
                    filter.includeMenuBar = true
                }

                let configuration = SCStreamConfiguration()
                configuration.width = max(1, display.width)
                configuration.height = max(1, display.height)
                configuration.showsCursor = false
                configuration.capturesAudio = false
                configuration.scalesToFit = false
                if #available(macOS 14.0, *) {
                    configuration.captureResolution = .best
                }

                SCScreenshotManager.captureImage(
                    contentFilter: filter,
                    configuration: configuration
                ) { image, _ in
                    if let image {
                        capturedImages.append(image)
                    }
                    group.leave()
                }
            }

            group.notify(queue: .global(qos: .userInitiated)) {
                semaphore.signal()
            }
        }

        let result = semaphore.wait(timeout: .now() + 8)
        return result == .success ? capturedImages : nil
    }

    private func decode(images: [CGImage]) -> [String] {
        var found = Set<String>()

        for image in images {
            for candidate in Self.scanCandidates(from: image) {
                Self.decodeWithVision(candidate).forEach { found.insert($0) }
            }
        }

        return found.sorted()
    }

    private static func scanCandidates(from image: CGImage) -> [CGImage] {
        var candidates = [image]

        let maxDimension = max(image.width, image.height)
        if maxDimension > 1800, let scaled = scaledImage(image, maxDimension: 1800) {
            candidates.append(scaled)
        }

        if maxDimension > 1000, let scaled = scaledImage(image, maxDimension: 1000) {
            candidates.append(scaled)
        }

        return candidates
    }

    private static func decodeWithVision(_ image: CGImage) -> [String] {
        let request = VNDetectBarcodesRequest()
        request.symbologies = [.qr]

        let handler = VNImageRequestHandler(cgImage: image, orientation: .up, options: [:])
        do {
            try handler.perform([request])
        } catch {
            return []
        }

        return (request.results ?? [])
            .compactMap { observation in
                observation.payloadStringValue?.trimmingCharacters(in: .whitespacesAndNewlines)
            }
            .filter { !$0.isEmpty }
    }

    private static func scaledImage(_ image: CGImage, maxDimension: Int) -> CGImage? {
        let width = image.width
        let height = image.height
        let currentMax = max(width, height)
        guard currentMax > maxDimension else {
            return image
        }

        let scale = CGFloat(maxDimension) / CGFloat(currentMax)
        let newWidth = max(1, Int(CGFloat(width) * scale))
        let newHeight = max(1, Int(CGFloat(height) * scale))

        guard let colorSpace = image.colorSpace ?? CGColorSpace(name: CGColorSpace.sRGB),
              let context = CGContext(
                data: nil,
                width: newWidth,
                height: newHeight,
                bitsPerComponent: 8,
                bytesPerRow: 0,
                space: colorSpace,
                bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
              ) else {
            return nil
        }

        context.interpolationQuality = .high
        context.draw(image, in: CGRect(x: 0, y: 0, width: newWidth, height: newHeight))
        return context.makeImage()
    }

}
