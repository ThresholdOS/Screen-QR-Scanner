import AppKit
import Carbon.HIToolbox
import Combine
import CoreGraphics
import Foundation
import ServiceManagement

extension Notification.Name {
    static let scanRequested = Notification.Name("MenuBarQRCodeScanner.scanRequested")
    static let hotKeyChanged = Notification.Name("MenuBarQRCodeScanner.hotKeyChanged")
    static let appLanguageChanged = Notification.Name("MenuBarQRCodeScanner.appLanguageChanged")
}

enum AppLanguage: String, CaseIterable, Identifiable {
    case simplifiedChinese = "zh-Hans"
    case englishUS = "en-US"

    var id: Self { self }

    var locale: Locale {
        switch self {
        case .simplifiedChinese:
            return Locale(identifier: "zh-Hans-CN")
        case .englishUS:
            return Locale(identifier: "en-US")
        }
    }

    static func systemDefault() -> AppLanguage {
        let preferred = (Locale.preferredLanguages.first ?? "").lowercased()
        let isSimplifiedChinese =
            preferred.hasPrefix("zh-hans")
            || preferred.hasPrefix("zh-cn")
            || preferred.hasPrefix("zh-sg")

        return isSimplifiedChinese ? .simplifiedChinese : .englishUS
    }
}

enum ScanActionMode: String, CaseIterable, Identifiable {
    case openAutomatically
    case copyOnly
    case askEveryTime

    var id: Self { self }
}

struct AppStrings {
    let language: AppLanguage

    private func value(_ chinese: String, _ english: String) -> String {
        language == .simplifiedChinese ? chinese : english
    }

    var appName: String { value("屏幕扫码", "Screen QR Scanner") }
    var scannerTitle: String { value("二维码扫描器", "QR Code Scanner") }
    var scannerSubtitle: String {
        value("点击菜单栏图标或按快捷键扫描当前屏幕", "Click the menu bar icon or use the hotkey to scan your screen")
    }
    var scanHistory: String { value("扫描记录", "Scan History") }
    var settings: String { value("设置", "Settings") }
    var scanNow: String { value("立即扫描", "Scan Now") }
    var clear: String { value("清空", "Clear") }
    var noRecords: String { value("暂无扫描记录", "No Scan History") }
    var noRecordsDetail: String { value("扫描到二维码后会显示在这里。", "Detected QR codes will appear here.") }
    var copiedContent: String { value("已复制内容", "Copied") }
    var openedLink: String { value("已打开链接", "Opened Link") }
    var copy: String { value("复制", "Copy") }
    var open: String { value("打开", "Open") }

    var languageSection: String { value("语言", "Language") }
    var appLanguage: String { value("应用语言", "App Language") }
    var scanBehavior: String { value("扫描", "Scanning") }
    var afterScan: String { value("扫描后操作", "After Scanning") }
    var openAutomatically: String { value("自动打开", "Open Automatically") }
    var copyOnly: String { value("仅复制", "Copy Only") }
    var askEveryTime: String { value("每次询问", "Ask Every Time") }
    var permissions: String { value("权限", "Permissions") }
    var permissionEnabled: String { value("屏幕录制权限已开启", "Screen Recording Access Enabled") }
    var permissionDisabled: String { value("屏幕录制权限未开启", "Screen Recording Access Disabled") }
    var recheck: String { value("重新检查", "Check Again") }
    var requestPermission: String { value("申请权限", "Request Access") }
    var openSystemSettings: String { value("打开系统设置", "Open System Settings") }
    var hotkey: String { value("快捷键", "Hotkey") }
    var globalScanHotkey: String { value("全局扫描快捷键", "Global Scan Hotkey") }
    var restoreDefault: String { value("恢复默认", "Restore Default") }
    var startup: String { value("启动", "Startup") }
    var launchAtLogin: String { value("登录时自动启动", "Launch at Login") }

    var openMainWindow: String { value("打开主界面", "Open Main Window") }
    var scanScreenNow: String { value("立即扫描屏幕", "Scan Screen Now") }
    var shortcutPrefix: String { value("快捷键", "Hotkey") }
    var quit: String { value("退出", "Quit") }
    var scanAccessibility: String { value("二维码扫描", "QR Code Scan") }

    var hotkeyUnavailableTitle: String { value("快捷键不可用", "Hotkey Unavailable") }
    var hotkeyUnavailableMessage: String {
        value(
            "应用已经启动，但全局快捷键注册失败。你仍然可以点击菜单栏图标扫描。",
            "The app is running, but the global hotkey could not be registered. You can still click the menu bar icon to scan."
        )
    }
    var noScreenPermissionTitle: String { value("没有屏幕录制权限", "Screen Recording Access Required") }
    var noScreenPermissionMessage: String {
        value(
            "我已经向 macOS 申请权限并打开系统设置。请在「录屏与系统录音」里打开此 App 的开关。授权后建议从「应用程序」里的同一个 App 重新启动。",
            "The app requested access and opened System Settings. Enable this app under Screen & System Audio Recording, then relaunch the same app from Applications."
        )
    }
    var scanFailed: String { value("扫描失败", "Scan Failed") }
    var qrNotFoundTitle: String { value("没有找到二维码", "No QR Code Found") }
    var qrNotFoundMessage: String {
        value("当前屏幕上没有识别到可读取的二维码。", "No readable QR code was found on the current screen.")
    }
    var copiedTitle: String { value("二维码内容已复制", "QR Code Content Copied") }
    var multipleCodesTitle: String { value("发现多个二维码", "Multiple QR Codes Found") }
    func multipleCodesMessage(count: Int) -> String {
        value("共识别到 \(count) 个二维码，请选择一个。", "\(count) QR codes were detected. Select one to continue.")
    }
    var select: String { value("选择", "Select") }
    var cancel: String { value("取消", "Cancel") }
    var qrCodeFoundTitle: String { value("识别到二维码", "QR Code Found") }

    func scanActionTitle(_ mode: ScanActionMode) -> String {
        switch mode {
        case .openAutomatically:
            return openAutomatically
        case .copyOnly:
            return copyOnly
        case .askEveryTime:
            return askEveryTime
        }
    }

    var launchApprovalRequired: String {
        value(
            "请在「系统设置 > 通用 > 登录项」中允许此 App。",
            "Allow this app in System Settings > General > Login Items."
        )
    }
    var launchAppNotFound: String {
        value(
            "系统找不到此 App，请从「应用程序」文件夹启动后再试。",
            "The app could not be found. Launch it from the Applications folder and try again."
        )
    }
    var launchStatusUnavailable: String {
        value("无法读取登录项状态。", "The login item status could not be read.")
    }

    var recorderPlaceholder: String { value("点击后按下快捷键", "Click to Record a Hotkey") }
    var recorderPrompt: String { value("请按下新的快捷键...", "Press a New Hotkey...") }
    var recorderNeedsModifier: String {
        value("请至少按住一个修饰键，再按一个普通键", "Hold at least one modifier, then press a regular key")
    }

    var noDisplays: String { value("没有找到可用的显示器。", "No available displays were found.") }
    var screenshotDenied: String {
        value(
            "macOS 不允许此应用读取屏幕。请打开「系统设置 > 隐私与安全性 > 屏幕录制」，允许此应用后重新运行。",
            "macOS did not allow this app to capture the screen. Enable it in System Settings > Privacy & Security > Screen Recording, then relaunch the app."
        )
    }

    func scannerError(_ error: Error) -> String {
        guard let scannerError = error as? ScreenQRCodeScannerError else {
            return error.localizedDescription
        }

        switch scannerError {
        case .noDisplays:
            return noDisplays
        case .screenshotDenied:
            return screenshotDenied
        }
    }
}

struct ScanRecord: Identifiable, Codable, Hashable {
    let id: UUID
    let content: String
    let date: Date
    let openedURLString: String?

    var openedURL: URL? {
        openedURLString.flatMap(URL.init(string:))
    }
}

struct HotKey: Codable, Equatable {
    let keyCode: UInt32
    let modifiers: UInt32
    let keyName: String

    static let `default` = HotKey(
        keyCode: UInt32(kVK_ANSI_Q),
        modifiers: UInt32(controlKey | optionKey | cmdKey),
        keyName: "Q"
    )

    var title: String {
        var parts: [String] = []
        if modifiers & UInt32(controlKey) != 0 { parts.append("Control") }
        if modifiers & UInt32(optionKey) != 0 { parts.append("Option") }
        if modifiers & UInt32(shiftKey) != 0 { parts.append("Shift") }
        if modifiers & UInt32(cmdKey) != 0 { parts.append("Command") }
        parts.append(keyName)
        return parts.joined(separator: " ")
    }
}

final class AppModel: ObservableObject {
    @Published var records: [ScanRecord] = [] {
        didSet { saveRecords() }
    }

    @Published var screenPermissionGranted = false
    @Published var launchAtLoginEnabled = false
    @Published var launchAtLoginError: String?
    @Published var appLanguage: AppLanguage {
        didSet {
            guard appLanguage != oldValue else {
                return
            }

            let changedLanguage = appLanguage
            UserDefaults.standard.set(appLanguage.rawValue, forKey: appLanguageKey)
            DispatchQueue.main.async { [weak self] in
                guard let self, self.appLanguage == changedLanguage else {
                    return
                }

                self.refreshLaunchAtLoginStatus()
                NotificationCenter.default.post(name: .appLanguageChanged, object: nil)
            }
        }
    }

    @Published var scanActionMode: ScanActionMode {
        didSet {
            guard scanActionMode != oldValue else {
                return
            }
            UserDefaults.standard.set(scanActionMode.rawValue, forKey: scanActionModeKey)
        }
    }

    @Published var selectedHotKey: HotKey = .default {
        didSet {
            saveHotKey()
            NotificationCenter.default.post(name: .hotKeyChanged, object: nil)
        }
    }

    private let recordsKey = "scanRecords"
    private let hotKeyKey = "selectedHotKey"
    private let appLanguageKey = "appLanguage"
    private let scanActionModeKey = "scanActionMode"

    init() {
        if let savedLanguage = UserDefaults.standard.string(forKey: appLanguageKey),
           let language = AppLanguage(rawValue: savedLanguage) {
            appLanguage = language
        } else {
            appLanguage = AppLanguage.systemDefault()
        }

        if let savedMode = UserDefaults.standard.string(forKey: scanActionModeKey),
           let mode = ScanActionMode(rawValue: savedMode) {
            scanActionMode = mode
        } else {
            scanActionMode = .openAutomatically
        }

        loadRecords()
        loadHotKey()
        refreshPermissions()
        refreshLaunchAtLoginStatus()
    }

    var strings: AppStrings {
        AppStrings(language: appLanguage)
    }

    func refreshPermissions() {
        let granted = CGPreflightScreenCaptureAccess()
        if screenPermissionGranted != granted {
            screenPermissionGranted = granted
        }
    }

    func requestScreenRecordingPermission() {
        let granted = CGRequestScreenCaptureAccess()
        let currentPermission = granted || CGPreflightScreenCaptureAccess()
        if screenPermissionGranted != currentPermission {
            screenPermissionGranted = currentPermission
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) { [weak self] in
            self?.refreshPermissions()
        }
    }

    func requestScreenRecordingPermissionAndOpenSettings() {
        ScreenQRCodeScanner.primeScreenCaptureKitPermission { [weak self] in
            guard let self else { return }
            self.requestScreenRecordingPermission()

            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { [weak self] in
                self?.openScreenRecordingSettings()
            }
        }
    }

    func openScreenRecordingSettings() {
        guard let url = URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture") else {
            return
        }
        NSWorkspace.shared.open(url)
    }

    func refreshLaunchAtLoginStatus() {
        let enabled: Bool
        let error: String?

        switch SMAppService.mainApp.status {
        case .enabled:
            enabled = true
            error = nil
        case .requiresApproval:
            enabled = false
            error = strings.launchApprovalRequired
        case .notFound:
            enabled = false
            error = strings.launchAppNotFound
        case .notRegistered:
            enabled = false
            error = nil
        @unknown default:
            enabled = false
            error = strings.launchStatusUnavailable
        }

        if launchAtLoginEnabled != enabled {
            launchAtLoginEnabled = enabled
        }
        if launchAtLoginError != error {
            launchAtLoginError = error
        }
    }

    func setLaunchAtLogin(_ enabled: Bool) {
        launchAtLoginError = nil

        do {
            if enabled {
                try SMAppService.mainApp.register()
            } else {
                try SMAppService.mainApp.unregister()
            }
            refreshLaunchAtLoginStatus()
        } catch {
            refreshLaunchAtLoginStatus()
            launchAtLoginError = error.localizedDescription
        }
    }

    func requestScan() {
        NotificationCenter.default.post(name: .scanRequested, object: nil)
    }

    func addRecord(content: String, openedURL: URL?) {
        let record = ScanRecord(
            id: UUID(),
            content: content,
            date: Date(),
            openedURLString: openedURL?.absoluteString
        )
        records.insert(record, at: 0)
        records = Array(records.prefix(200))
    }

    func clearRecords() {
        records.removeAll()
    }

    func resetHotKey() {
        selectedHotKey = .default
    }

    func copy(_ content: String) {
        NSPasteboard.general.clearContents()
        NSPasteboard.general.setString(content, forType: .string)
    }

    private func loadRecords() {
        guard let data = UserDefaults.standard.data(forKey: recordsKey),
              let decoded = try? JSONDecoder().decode([ScanRecord].self, from: data) else {
            return
        }
        records = decoded
    }

    private func saveRecords() {
        guard let data = try? JSONEncoder().encode(records) else {
            return
        }
        UserDefaults.standard.set(data, forKey: recordsKey)
    }

    private func loadHotKey() {
        guard let data = UserDefaults.standard.data(forKey: hotKeyKey),
              let hotKey = try? JSONDecoder().decode(HotKey.self, from: data) else {
            return
        }
        selectedHotKey = hotKey
    }

    private func saveHotKey() {
        guard let data = try? JSONEncoder().encode(selectedHotKey) else {
            return
        }
        UserDefaults.standard.set(data, forKey: hotKeyKey)
    }
}

extension URL {
    static func qrURL(from string: String) -> URL? {
        let trimmed = string.trimmingCharacters(in: .whitespacesAndNewlines)

        if let url = URL(string: trimmed), ["http", "https"].contains(url.scheme?.lowercased()) {
            return url
        }

        if trimmed.contains("."), !trimmed.contains(" ") {
            return URL(string: "https://" + trimmed)
        }

        return nil
    }
}
