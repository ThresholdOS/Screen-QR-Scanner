import AppKit
import Carbon.HIToolbox
import SwiftUI

final class AppDelegate: NSObject, NSApplicationDelegate, NSWindowDelegate {
    private var statusItem: NSStatusItem?
    private var statusMenu: NSMenu?
    private var mainWindow: NSWindow?
    private var hotKeyRef: EventHotKeyRef?
    private var hotKeyHandlerInstalled = false
    private let model = AppModel()
    private let scanner = ScreenQRCodeScanner()

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory)
        setupStatusItem()
        setupMainWindow()
        setupObservers()
        registerHotKey()
        checkPermissionsOnLaunch()
    }

    func applicationWillTerminate(_ notification: Notification) {
        if let hotKeyRef {
            UnregisterEventHotKey(hotKeyRef)
        }
    }

    func applicationDidBecomeActive(_ notification: Notification) {
        DispatchQueue.main.async { [weak self] in
            self?.model.refreshPermissions()
            self?.model.refreshLaunchAtLoginStatus()
        }
    }

    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool {
        showMainWindow()
        return true
    }

    func windowWillClose(_ notification: Notification) {
        guard notification.object as? NSWindow === mainWindow else {
            return
        }

        DispatchQueue.main.async {
            guard self.mainWindow?.isVisible != true else {
                return
            }
            NSApp.setActivationPolicy(.accessory)
        }
    }

    private func setupStatusItem() {
        if let statusItem {
            NSStatusBar.system.removeStatusItem(statusItem)
            self.statusItem = nil
        }

        let item = NSStatusBar.system.statusItem(withLength: NSStatusItem.squareLength)
        statusItem = item

        if let button = item.button {
            button.image = NSImage(
                systemSymbolName: "qrcode.viewfinder",
                accessibilityDescription: model.strings.scanAccessibility
            )
            button.image?.isTemplate = true
            button.action = #selector(statusItemClicked)
            button.target = self
            button.sendAction(on: [.leftMouseUp, .rightMouseUp])
        }

        let menu = NSMenu()
        menu.addItem(NSMenuItem(title: model.strings.openMainWindow, action: #selector(showMainWindow), keyEquivalent: ""))
        menu.addItem(NSMenuItem(title: model.strings.scanScreenNow, action: #selector(scanNow), keyEquivalent: ""))
        menu.addItem(
            NSMenuItem(
                title: "\(model.strings.shortcutPrefix): \(model.selectedHotKey.title)",
                action: nil,
                keyEquivalent: ""
            )
        )
        menu.addItem(.separator())
        menu.addItem(NSMenuItem(title: model.strings.quit, action: #selector(quit), keyEquivalent: "q"))
        statusMenu = menu
    }

    private func setupMainWindow() {
        let contentView = ContentView()
            .environmentObject(model)

        let window = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 760, height: 560),
            styleMask: [.titled, .closable, .miniaturizable, .resizable],
            backing: .buffered,
            defer: false
        )
        window.title = model.strings.appName
        window.minSize = NSSize(width: 720, height: 520)
        window.contentViewController = NSHostingController(rootView: contentView)
        window.isReleasedWhenClosed = false
        window.tabbingMode = .disallowed
        window.delegate = self
        window.setFrameAutosaveName("ScreenQRCodeScannerMainWindow")
        if !window.setFrameUsingName("ScreenQRCodeScannerMainWindow") {
            window.center()
        }
        mainWindow = window
    }

    private func setupObservers() {
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(scanNow),
            name: .scanRequested,
            object: nil
        )

        NotificationCenter.default.addObserver(
            self,
            selector: #selector(hotKeyDidChange),
            name: .hotKeyChanged,
            object: nil
        )

        NotificationCenter.default.addObserver(
            self,
            selector: #selector(appLanguageDidChange),
            name: .appLanguageChanged,
            object: nil
        )
    }

    private func checkPermissionsOnLaunch() {
        model.refreshPermissions()
        guard !model.screenPermissionGranted else {
            return
        }

        showMainWindow()

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { [weak self] in
            guard let self else { return }
            self.model.requestScreenRecordingPermissionAndOpenSettings()

            DispatchQueue.main.asyncAfter(deadline: .now() + 0.9) {
                self.model.refreshPermissions()
            }
        }
    }

    private func registerHotKey() {
        unregisterHotKey()

        let hotKeyID = EventHotKeyID(signature: OSType("QRS1".fourCharCode), id: 1)
        let modifiers = model.selectedHotKey.modifiers
        let keyCode = model.selectedHotKey.keyCode

        let status = RegisterEventHotKey(keyCode, modifiers, hotKeyID, GetApplicationEventTarget(), 0, &hotKeyRef)
        guard status == noErr else {
            showMessage(
                title: model.strings.hotkeyUnavailableTitle,
                message: model.strings.hotkeyUnavailableMessage
            )
            return
        }

        installHotKeyHandlerIfNeeded()
    }

    private func installHotKeyHandlerIfNeeded() {
        guard !hotKeyHandlerInstalled else {
            return
        }

        var eventType = EventTypeSpec(eventClass: OSType(kEventClassKeyboard), eventKind: UInt32(kEventHotKeyPressed))
        InstallEventHandler(GetApplicationEventTarget(), { _, event, userData in
            var hotKeyID = EventHotKeyID()
            GetEventParameter(
                event,
                EventParamName(kEventParamDirectObject),
                EventParamType(typeEventHotKeyID),
                nil,
                MemoryLayout<EventHotKeyID>.size,
                nil,
                &hotKeyID
            )

            if hotKeyID.id == 1, let userData {
                let appDelegate = Unmanaged<AppDelegate>.fromOpaque(userData).takeUnretainedValue()
                appDelegate.scanNow()
            }

            return noErr
        }, 1, &eventType, Unmanaged.passUnretained(self).toOpaque(), nil)
        hotKeyHandlerInstalled = true
    }

    private func unregisterHotKey() {
        if let hotKeyRef {
            UnregisterEventHotKey(hotKeyRef)
            self.hotKeyRef = nil
        }
    }

    @objc private func hotKeyDidChange() {
        registerHotKey()
        setupStatusItem()
    }

    @objc private func appLanguageDidChange() {
        mainWindow?.title = model.strings.appName
        setupStatusItem()
        updateMainMenuLanguage()
    }

    @objc private func scanNow() {
        model.refreshPermissions()
        guard model.screenPermissionGranted else {
            showMainWindow()
            model.requestScreenRecordingPermissionAndOpenSettings()
            showMessage(
                title: model.strings.noScreenPermissionTitle,
                message: model.strings.noScreenPermissionMessage
            )
            return
        }

        scanner.scanAllDisplays { [weak self] result in
            switch result {
            case .success(let codes):
                self?.handle(codes: codes)
            case .failure(let error):
                guard let self else { return }
                self.showMessage(
                    title: self.model.strings.scanFailed,
                    message: self.model.strings.scannerError(error)
                )
            }
        }
    }

    @objc private func statusItemClicked() {
        guard NSApp.currentEvent?.type == .rightMouseUp, let statusMenu else {
            scanNow()
            return
        }

        statusItem?.menu = statusMenu
        statusItem?.button?.performClick(nil)
        statusItem?.menu = nil
    }

    private func handle(codes: [String]) {
        guard !codes.isEmpty else {
            showMessage(
                title: model.strings.qrNotFoundTitle,
                message: model.strings.qrNotFoundMessage
            )
            return
        }

        let selectedCode: String
        if codes.count == 1 {
            selectedCode = codes[0]
        } else {
            guard let code = selectCode(from: codes) else {
                return
            }
            selectedCode = code
        }

        handle(code: selectedCode)
    }

    private func handle(code: String) {
        let url = URL.qrURL(from: code)

        switch model.scanActionMode {
        case .openAutomatically:
            copyToPasteboard(code)
            if let url {
                model.addRecord(content: code, openedURL: url)
                NSWorkspace.shared.open(url)
            } else {
                model.addRecord(content: code, openedURL: nil)
                showMessage(title: model.strings.copiedTitle, message: code)
            }

        case .copyOnly:
            copyToPasteboard(code)
            model.addRecord(content: code, openedURL: nil)
            showMessage(title: model.strings.copiedTitle, message: code)

        case .askEveryTime:
            askHowToHandle(code: code, url: url)
        }
    }

    private func copyToPasteboard(_ content: String) {
        NSPasteboard.general.clearContents()
        NSPasteboard.general.setString(content, forType: .string)
    }

    private func askHowToHandle(code: String, url: URL?) {
        NSApp.activate(ignoringOtherApps: true)

        let alert = NSAlert()
        alert.messageText = model.strings.qrCodeFoundTitle
        alert.informativeText = code

        if let url {
            alert.addButton(withTitle: model.strings.open)
            alert.addButton(withTitle: model.strings.copy)
            alert.addButton(withTitle: model.strings.cancel)

            switch alert.runModal() {
            case .alertFirstButtonReturn:
                model.addRecord(content: code, openedURL: url)
                NSWorkspace.shared.open(url)
            case .alertSecondButtonReturn:
                copyToPasteboard(code)
                model.addRecord(content: code, openedURL: nil)
            default:
                break
            }
            return
        }

        alert.addButton(withTitle: model.strings.copy)
        alert.addButton(withTitle: model.strings.cancel)
        if alert.runModal() == .alertFirstButtonReturn {
            copyToPasteboard(code)
            model.addRecord(content: code, openedURL: nil)
        }
    }

    private func selectCode(from codes: [String]) -> String? {
        NSApp.activate(ignoringOtherApps: true)

        let alert = NSAlert()
        alert.messageText = model.strings.multipleCodesTitle
        alert.informativeText = model.strings.multipleCodesMessage(count: codes.count)

        let selectionView = QRCodeSelectionView(codes: codes)
        alert.accessoryView = selectionView
        alert.addButton(withTitle: model.strings.select)
        alert.addButton(withTitle: model.strings.cancel)

        guard alert.runModal() == .alertFirstButtonReturn else {
            return nil
        }
        return selectionView.selectedCode
    }

    private func showMessage(title: String, message: String) {
        DispatchQueue.main.async {
            NSApp.activate(ignoringOtherApps: true)
            let alert = NSAlert()
            alert.messageText = title
            alert.informativeText = message
            alert.addButton(withTitle: "OK")
            alert.runModal()
        }
    }

    @objc private func showMainWindow() {
        model.refreshPermissions()
        NSApp.setActivationPolicy(.regular)
        NSApp.activate(ignoringOtherApps: true)
        mainWindow?.makeKeyAndOrderFront(nil)
        updateMainMenuLanguage()
    }

    private func updateMainMenuLanguage() {
        NSApp.mainMenu?.items.first?.title = model.strings.appName
    }

    @objc private func quit() {
        NSApp.terminate(nil)
    }
}

private final class QRCodeSelectionView: NSView, NSTableViewDataSource, NSTableViewDelegate {
    private let codes: [String]
    private let tableView = NSTableView()

    var selectedCode: String? {
        let row = tableView.selectedRow
        guard codes.indices.contains(row) else {
            return nil
        }
        return codes[row]
    }

    init(codes: [String]) {
        self.codes = codes
        super.init(frame: NSRect(x: 0, y: 0, width: 520, height: 220))

        let column = NSTableColumn(identifier: NSUserInterfaceItemIdentifier("QRCode"))
        column.width = 500
        tableView.addTableColumn(column)
        tableView.headerView = nil
        tableView.rowHeight = 42
        tableView.intercellSpacing = NSSize(width: 0, height: 2)
        tableView.dataSource = self
        tableView.delegate = self
        tableView.allowsEmptySelection = false
        tableView.allowsMultipleSelection = false

        let scrollView = NSScrollView(frame: bounds)
        scrollView.autoresizingMask = [.width, .height]
        scrollView.documentView = tableView
        scrollView.hasVerticalScroller = true
        scrollView.drawsBackground = false
        addSubview(scrollView)

        if !codes.isEmpty {
            tableView.selectRowIndexes(IndexSet(integer: 0), byExtendingSelection: false)
        }
    }

    required init?(coder: NSCoder) {
        nil
    }

    func numberOfRows(in tableView: NSTableView) -> Int {
        codes.count
    }

    func tableView(_ tableView: NSTableView, viewFor tableColumn: NSTableColumn?, row: Int) -> NSView? {
        let cell = NSTableCellView()
        let textField = NSTextField(wrappingLabelWithString: codes[row])
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.maximumNumberOfLines = 2
        textField.lineBreakMode = .byTruncatingMiddle
        textField.toolTip = codes[row]

        cell.addSubview(textField)
        NSLayoutConstraint.activate([
            textField.leadingAnchor.constraint(equalTo: cell.leadingAnchor, constant: 8),
            textField.trailingAnchor.constraint(equalTo: cell.trailingAnchor, constant: -8),
            textField.centerYAnchor.constraint(equalTo: cell.centerYAnchor)
        ])
        return cell
    }
}

private extension String {
    var fourCharCode: FourCharCode {
        utf16.reduce(0) { ($0 << 8) + FourCharCode($1) }
    }
}
