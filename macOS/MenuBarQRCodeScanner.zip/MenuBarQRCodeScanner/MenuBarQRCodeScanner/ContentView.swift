import AppKit
import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var model: AppModel

    var body: some View {
        VStack(spacing: 0) {
            header

            TabView {
                RecordsView()
                    .tabItem {
                        Label(model.strings.scanHistory, systemImage: "clock")
                    }

                SettingsView()
                    .tabItem {
                        Label(model.strings.settings, systemImage: "gearshape")
                    }
            }
            .padding(.horizontal, 18)
            .padding(.bottom, 18)
        }
        .frame(minWidth: 720, minHeight: 520)
        .background(Color(nsColor: .windowBackgroundColor))
        .environment(\.locale, model.appLanguage.locale)
    }

    private var header: some View {
        HStack(spacing: 12) {
            Image(systemName: "qrcode.viewfinder")
                .font(.system(size: 34))
                .foregroundStyle(.blue)

            VStack(alignment: .leading, spacing: 3) {
                Text(model.strings.scannerTitle)
                    .font(.title2.bold())
                Text(model.strings.scannerSubtitle)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Button {
                model.requestScan()
            } label: {
                Label(model.strings.scanNow, systemImage: "viewfinder")
            }
            .buttonStyle(.borderedProminent)
            .keyboardShortcut(.return, modifiers: [.command])
        }
        .padding(20)
    }
}

private struct RecordsView: View {
    @EnvironmentObject private var model: AppModel

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text(model.strings.scanHistory)
                    .font(.headline)
                Spacer()
                Button {
                    model.clearRecords()
                } label: {
                    Label(model.strings.clear, systemImage: "trash")
                }
                .disabled(model.records.isEmpty)
            }

            if model.records.isEmpty {
                VStack(spacing: 10) {
                    Image(systemName: "qrcode")
                        .font(.system(size: 42))
                        .foregroundStyle(.secondary)
                    Text(model.strings.noRecords)
                        .font(.headline)
                    Text(model.strings.noRecordsDetail)
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                List(model.records) { record in
                    RecordRow(record: record)
                        .padding(.vertical, 6)
                }
                .listStyle(.inset)
            }
        }
    }
}

private struct RecordRow: View {
    @EnvironmentObject private var model: AppModel
    let record: ScanRecord

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: record.openedURL == nil ? "doc.on.clipboard" : "safari")
                .font(.title3)
                .foregroundStyle(record.openedURL == nil ? Color.secondary : Color.blue)
                .frame(width: 26)

            VStack(alignment: .leading, spacing: 5) {
                Text(record.content)
                    .lineLimit(2)
                    .textSelection(.enabled)

                HStack(spacing: 8) {
                    Text(record.date.formatted(date: .abbreviated, time: .standard))
                    Text(record.openedURL == nil ? model.strings.copiedContent : model.strings.openedLink)
                }
                .font(.caption)
                .foregroundStyle(.secondary)
            }

            Spacer()

            Button {
                model.copy(record.content)
            } label: {
                Label(model.strings.copy, systemImage: "doc.on.doc")
            }

            if let url = record.openedURL {
                Button {
                    NSWorkspace.shared.open(url)
                } label: {
                    Label(model.strings.open, systemImage: "arrow.up.right.square")
                }
            }
        }
    }
}

private struct SettingsView: View {
    @EnvironmentObject private var model: AppModel

    var body: some View {
        Form {
            Section(model.strings.languageSection) {
                Picker(model.strings.appLanguage, selection: appLanguageBinding) {
                    Text("简体中文")
                        .tag(AppLanguage.simplifiedChinese)
                    Text("English (US)")
                        .tag(AppLanguage.englishUS)
                }
                .pickerStyle(.segmented)
            }

            Section(model.strings.scanBehavior) {
                Picker(model.strings.afterScan, selection: scanActionModeBinding) {
                    ForEach(ScanActionMode.allCases) { mode in
                        Text(model.strings.scanActionTitle(mode))
                            .tag(mode)
                    }
                }
                .pickerStyle(.segmented)
            }

            Section(model.strings.permissions) {
                HStack {
                    Label(
                        model.screenPermissionGranted
                            ? model.strings.permissionEnabled
                            : model.strings.permissionDisabled,
                        systemImage: model.screenPermissionGranted
                            ? "checkmark.circle.fill"
                            : "exclamationmark.triangle.fill"
                    )
                    .foregroundStyle(model.screenPermissionGranted ? .green : .orange)

                    Spacer()

                    Button(model.strings.recheck) {
                        model.refreshPermissions()
                    }

                    Button(model.strings.requestPermission) {
                        model.requestScreenRecordingPermissionAndOpenSettings()
                    }

                    Button(model.strings.openSystemSettings) {
                        model.openScreenRecordingSettings()
                    }
                }
            }

            Section(model.strings.hotkey) {
                HStack {
                    Text(model.strings.globalScanHotkey)
                    Spacer()
                    HotKeyRecorderView(hotKey: $model.selectedHotKey, language: model.appLanguage)
                        .frame(width: 260, height: 30)
                    Button(model.strings.restoreDefault) {
                        model.resetHotKey()
                    }
                }
            }

            Section(model.strings.startup) {
                Toggle(
                    model.strings.launchAtLogin,
                    isOn: launchAtLoginBinding
                )

                if let error = model.launchAtLoginError {
                    Label(error, systemImage: "exclamationmark.triangle.fill")
                        .foregroundStyle(.orange)
                }
            }
        }
        .formStyle(.grouped)
    }

    private var appLanguageBinding: Binding<AppLanguage> {
        Binding(
            get: { model.appLanguage },
            set: { language in
                guard language != model.appLanguage else {
                    return
                }

                DispatchQueue.main.async {
                    model.appLanguage = language
                }
            }
        )
    }

    private var launchAtLoginBinding: Binding<Bool> {
        Binding(
            get: { model.launchAtLoginEnabled },
            set: { enabled in
                guard enabled != model.launchAtLoginEnabled else {
                    return
                }

                DispatchQueue.main.async {
                    model.setLaunchAtLogin(enabled)
                }
            }
        )
    }

    private var scanActionModeBinding: Binding<ScanActionMode> {
        Binding(
            get: { model.scanActionMode },
            set: { mode in
                guard mode != model.scanActionMode else {
                    return
                }

                DispatchQueue.main.async {
                    model.scanActionMode = mode
                }
            }
        )
    }
}
