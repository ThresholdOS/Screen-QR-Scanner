import AppKit
import Carbon.HIToolbox
import SwiftUI

struct HotKeyRecorderView: NSViewRepresentable {
    @Binding var hotKey: HotKey
    let language: AppLanguage

    func makeCoordinator() -> Coordinator {
        Coordinator(hotKey: $hotKey)
    }

    func makeNSView(context: Context) -> HotKeyRecorderField {
        let field = HotKeyRecorderField()
        field.language = language
        field.onChange = { hotKey in
            context.coordinator.hotKey = hotKey
        }
        field.stringValue = hotKey.title
        return field
    }

    func updateNSView(_ nsView: HotKeyRecorderField, context: Context) {
        nsView.language = language
        if !nsView.isRecording {
            nsView.stringValue = hotKey.title
            nsView.updateLanguage()
        }
    }

    final class Coordinator {
        @Binding var hotKey: HotKey

        init(hotKey: Binding<HotKey>) {
            _hotKey = hotKey
        }
    }
}

final class HotKeyRecorderField: NSTextField {
    var onChange: ((HotKey) -> Void)?
    var isRecording = false
    var language: AppLanguage = .englishUS

    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        commonInit()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        commonInit()
    }

    private func commonInit() {
        isEditable = false
        isSelectable = false
        isBordered = true
        drawsBackground = true
        backgroundColor = .textBackgroundColor
        focusRingType = .default
        alignment = .center
        font = .monospacedSystemFont(ofSize: 13, weight: .medium)
        updateLanguage()
    }

    override var acceptsFirstResponder: Bool {
        true
    }

    override func mouseDown(with event: NSEvent) {
        window?.makeFirstResponder(self)
        beginRecording()
    }

    override func becomeFirstResponder() -> Bool {
        beginRecording()
        return true
    }

    override func resignFirstResponder() -> Bool {
        isRecording = false
        return true
    }

    override func keyDown(with event: NSEvent) {
        record(event)
    }

    override func performKeyEquivalent(with event: NSEvent) -> Bool {
        guard isRecording, event.type == .keyDown else {
            return super.performKeyEquivalent(with: event)
        }

        record(event)
        return true
    }

    override func flagsChanged(with event: NSEvent) {
        guard isRecording else {
            super.flagsChanged(with: event)
            return
        }

        let modifiers = event.modifierFlags.displayNames
        stringValue = modifiers.isEmpty
            ? strings.recorderPrompt
            : modifiers.joined(separator: " + ") + " + …"
    }

    private func record(_ event: NSEvent) {
        if event.keyCode == UInt16(kVK_Escape) {
            isRecording = false
            window?.makeFirstResponder(nil)
            return
        }

        let keyCode = UInt32(event.keyCode)
        guard !Self.modifierOnlyKeyCodes.contains(keyCode) else {
            return
        }

        let modifiers = event.modifierFlags.carbonHotKeyModifiers
        guard modifiers != 0 else {
            stringValue = strings.recorderNeedsModifier
            return
        }

        let keyName = Self.keyName(for: event)
        let hotKey = HotKey(keyCode: keyCode, modifiers: modifiers, keyName: keyName)
        stringValue = hotKey.title
        isRecording = false
        onChange?(hotKey)
        DispatchQueue.main.async { [weak self] in
            self?.stringValue = hotKey.title
            self?.window?.makeFirstResponder(nil)
        }
    }

    private func beginRecording() {
        isRecording = true
        stringValue = strings.recorderPrompt
    }

    func updateLanguage() {
        placeholderString = strings.recorderPlaceholder
    }

    private var strings: AppStrings {
        AppStrings(language: language)
    }

    private static let modifierOnlyKeyCodes: Set<UInt32> = [
        UInt32(kVK_Command),
        UInt32(kVK_RightCommand),
        UInt32(kVK_Shift),
        UInt32(kVK_RightShift),
        UInt32(kVK_Option),
        UInt32(kVK_RightOption),
        UInt32(kVK_Control),
        UInt32(kVK_RightControl),
        UInt32(kVK_CapsLock),
        UInt32(kVK_Function)
    ]

    private static func keyName(for event: NSEvent) -> String {
        if let name = specialKeyName(for: UInt32(event.keyCode)) {
            return name
        }

        let raw = event.charactersIgnoringModifiers?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        if raw.isEmpty {
            return "Key \(event.keyCode)"
        }
        return raw.uppercased()
    }

    private static func specialKeyName(for keyCode: UInt32) -> String? {
        switch Int(keyCode) {
        case kVK_Return: return "Return"
        case kVK_Tab: return "Tab"
        case kVK_Space: return "Space"
        case kVK_Delete: return "Delete"
        case kVK_Escape: return "Escape"
        case kVK_F1: return "F1"
        case kVK_F2: return "F2"
        case kVK_F3: return "F3"
        case kVK_F4: return "F4"
        case kVK_F5: return "F5"
        case kVK_F6: return "F6"
        case kVK_F7: return "F7"
        case kVK_F8: return "F8"
        case kVK_F9: return "F9"
        case kVK_F10: return "F10"
        case kVK_F11: return "F11"
        case kVK_F12: return "F12"
        case kVK_LeftArrow: return "Left"
        case kVK_RightArrow: return "Right"
        case kVK_UpArrow: return "Up"
        case kVK_DownArrow: return "Down"
        default: return nil
        }
    }
}

private extension NSEvent.ModifierFlags {
    var displayNames: [String] {
        var names: [String] = []
        if contains(.control) { names.append("Control") }
        if contains(.option) { names.append("Option") }
        if contains(.shift) { names.append("Shift") }
        if contains(.command) { names.append("Command") }
        return names
    }

    var carbonHotKeyModifiers: UInt32 {
        var modifiers: UInt32 = 0
        if contains(.control) { modifiers |= UInt32(controlKey) }
        if contains(.option) { modifiers |= UInt32(optionKey) }
        if contains(.shift) { modifiers |= UInt32(shiftKey) }
        if contains(.command) { modifiers |= UInt32(cmdKey) }
        return modifiers
    }
}
