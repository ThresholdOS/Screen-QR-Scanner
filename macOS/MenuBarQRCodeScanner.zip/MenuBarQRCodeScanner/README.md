# Screen QR Code Scanner for macOS

Screen QR Code Scanner is a native macOS menu bar utility that detects QR codes displayed on your screen. Click the menu bar icon or press a global hotkey to scan all connected displays. It is a standalone app and does not require a browser extension.

## Features

- Scans QR codes across all connected displays
- Captures visible window content with ScreenCaptureKit
- Decodes QR codes locally with Apple Vision
- Opens detected URLs in the default browser
- Copies every scan result to the clipboard
- Stores the 200 most recent scan results
- Supports recording and resetting the global hotkey
- Supports launch at login
- Supports Simplified Chinese and English (US)
- Runs quietly in the macOS menu bar
- Opens as a regular foreground app when the main window is shown

## Requirements

- macOS 14.6 or later
- Xcode with a current macOS SDK
- Screen Recording permission

## Build

1. Open `MenuBarQRCodeScanner.xcodeproj` in Xcode.
2. Select the `MenuBarQRCodeScanner` target.
3. Open `Signing & Capabilities`, select your Team, and enable automatic signing.
4. Build or run the app.
5. Copy the built app to `/Applications` and launch it from the Applications folder.

Keep the same bundle identifier and signing identity between builds. Changing either may cause macOS to treat the build as a different app and request Screen Recording permission again.

## Screen Recording Permission

On first launch, the app requests Screen Recording access and opens:

`System Settings > Privacy & Security > Screen & System Audio Recording`

If the app does not appear automatically, use the `+` button on the permission page and select the installed app from `/Applications`. Quit and relaunch the app after granting access.

For reliable local testing, sign the app with a valid Apple Development identity. Unsigned builds, invalid signatures, and changing bundle identifiers may not retain system permissions.

## Language

The first launch uses Simplified Chinese only when the system's preferred language is Simplified Chinese. Every other system language defaults to English (US).

The language can be changed at any time under:

`Settings > Language`

The selected language is saved and takes priority on future launches.

## Usage

- Left-click the QR code icon in the menu bar to scan immediately.
- Right-click the icon to open the app menu.
- Open the main window to access scan history and settings.
- Default hotkey: `Control + Option + Command + Q`
- To change the hotkey, click the recorder field, hold at least one modifier, and press a regular key.
- Press `Esc` to cancel hotkey recording.

When a URL is detected, the app copies it and opens it in the default browser. Other text content is copied and displayed in an alert.

## Main Window

- **Scan History**: Shows the 200 most recent results, with copy and reopen actions
- **Language**: Switches between Simplified Chinese and English (US)
- **Permissions**: Checks access, requests permission, and opens System Settings
- **Hotkey**: Records a new global shortcut or restores the default
- **Startup**: Controls launch at login

The app appears in the Dock and becomes the active foreground app while the main window is open. Closing the window returns it to menu bar mode.

## Privacy

Screen capture and QR code recognition happen entirely on the Mac. The app does not upload screenshots or scan results. When a QR code contains a URL, the app passes that URL to the system default browser.

## Project Structure

```text
MenuBarQRCodeScanner/
├── MenuBarQRCodeScanner.xcodeproj
├── README.md
└── MenuBarQRCodeScanner/
    ├── AppDelegate.swift
    ├── AppModel.swift
    ├── Assets.xcassets/
    ├── ContentView.swift
    ├── HotKeyRecorderView.swift
    ├── Info.plist
    ├── MenuBarQRCodeScannerApp.swift
    └── ScreenQRCodeScanner.swift
```
